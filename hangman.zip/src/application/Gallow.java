package application;

import javafx.scene.*;
import javafx.scene.shape.*;
public class Gallow extends Shape{

	public static void main(String[] args) {

		Line line = new Line(50, Main.getScreenHeight() - 40, 50, 40);
		
	}

}
