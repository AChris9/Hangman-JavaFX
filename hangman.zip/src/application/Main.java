package application;
	
import java.io.*;
import java.util.*;

import javafx.application.Application;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.BorderPane;
import javafx.scene.paint.Color;
import javafx.scene.shape.*;
import javafx.scene.text.*;

public class Main extends Application {
	
	
	final static double screenWidth = 400;
	final static double screenHeight = 400;
	
	int nextBodyPart = 0;
	ArrayList<String> words = new ArrayList<String>();
	ArrayList<Character> lettersInHiddenWord = new ArrayList<Character>();
	ArrayList<Boolean> lettersFound = new ArrayList<Boolean>();
	ArrayList<Text> textObjects = new ArrayList<Text>();
	ArrayList<Shape> bodyObjects = new ArrayList<Shape>();

	String selectedWord;
	Text hiddenWord;
	String hiddenSymbol = "*";
	int indexOfCorrectLetter = 0;
	boolean isGameOver = false;

	@Override
	public void start(Stage primaryStage) {

		try {

			BorderPane root = new BorderPane();
			CreateGallow(root);
			Scene scene = new Scene(root,screenWidth,screenHeight);
			scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
			primaryStage.setScene(scene);
			primaryStage.show();
			

			
			//Set word list
			SetWordList();
			
			//Select Random Word
			selectedWord = SelectWord();
			System.out.println("Selected Word: " + selectedWord);

			//Set letter list
			for(int i = 0; i < selectedWord.length(); i++) {
				lettersInHiddenWord.add(selectedWord.charAt(i));
				lettersFound.add(false);
			}
			
			//Create a text that is asterisks the length of the selected word.
			
			hiddenWord = new Text(300, 350, asterisks());
			hiddenWord.setScaleX(2);
			hiddenWord.setScaleY(2);

			root.getChildren().add(hiddenWord);
			
			//Check when a key is pressed and store key with a scanner
			
			scene.addEventHandler(KeyEvent.KEY_PRESSED, (key) -> {
				if(key.getCode().isLetterKey()) {
					String s = key.getCode().toString();
					Character c = Character.toLowerCase(s.charAt(0));

					System.out.println("Selected Letter: " + c);
					
					//Is the letter in the hidden word
					if(isCorrectLetter(c)) {
						hiddenWord.setText(UpdateHiddenWord(c));
						System.out.println("Updated Word: " + hiddenWord.getText());
					}
					else {
						PlaceNextBodyPart(root);
					}
					//Check if complete
					if(isComplete()) {
						Text text = new Text(screenWidth/2 - 50, screenHeight/2, "You Win!\nPress Enter");
						textObjects.add(text);
						text.setScaleX(2);
						text.setScaleY(2);
						text.setTextAlignment(TextAlignment.CENTER);
						root.getChildren().add(text);
					}
				}
				
			
				if(isComplete() && key.getCode() == KeyCode.ENTER) {
					ClearGame(root);
					SetupGame(root);
					System.out.println("Removed Texts");
				}
				if(isGameOver && key.getCode() == KeyCode.ENTER) {
					ClearGame(root);
					SetupGame(root);
					System.out.println("Removed Texts");

				}
			});
			
			
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	public void SetWordList() {
		String word = null;
		File file = new File("wordList.txt");
		if(file.exists()) {
			System.out.println("Found File: " + file.getName());
		}
		
		try {
			Scanner fileScanner = new Scanner(file);
				
			while(fileScanner.hasNext()) {
				word = fileScanner.next();
				words.add(word);
			}
		} catch (FileNotFoundException e) {
				e.printStackTrace();
		}
		
		
		
	}
	public String SelectWord() {

		int random = (int)(Math.random() * words.size());
		return words.get(random);
		
	}
	
	public void CreateGallow(BorderPane root) {
		root.getChildren().add(new Line(50, Main.getScreenHeight() - 40, 50, 40));
		root.getChildren().add(new Line(50, 40, 200, 40));
		root.getChildren().add(new Line(200, 40, 200, 80));
	}
	public void PlaceNextBodyPart(BorderPane root) {
		switch(nextBodyPart) {
		case 0:
			//Head
			Circle head = new Circle(200, 120, 40);
			head.setFill(Color.WHITE);
			head.setStroke(Color.BLACK);
			bodyObjects.add(head);
			root.getChildren().add(head);
			System.out.println("Placed Head");
			nextBodyPart++;
			break;
		case 1:
			//Left Arm
			Line leftArm = new Line(165, 140, 120, 180);
			leftArm.setFill(Color.WHITE);
			leftArm.setStroke(Color.BLACK);
			bodyObjects.add(leftArm);

			root.getChildren().add(leftArm);
			System.out.println("Placed left arm");
			nextBodyPart++;
			break;
		case 2:			
			//Right Arm
			Line rightArm = new Line(235, 140, 235 + 45, 180);
			rightArm.setFill(Color.WHITE);
			rightArm.setStroke(Color.BLACK);
			bodyObjects.add(rightArm);

			root.getChildren().add(rightArm);
			System.out.println("Placed right arm");
			nextBodyPart++;
			break;
		case 3:
			//Body
			Line body = new Line(200, 160, 200, 250);
			body.setFill(Color.WHITE);
			body.setStroke(Color.BLACK);
			bodyObjects.add(body);

			root.getChildren().add(body);
			System.out.println("Placed Body");
			nextBodyPart++;
			break;
		case 4:
			//Left Leg
			Line leftLeg = new Line(200, 250, 200-45, 250+40);
			leftLeg.setFill(Color.WHITE);
			leftLeg.setStroke(Color.BLACK);
			bodyObjects.add(leftLeg);

			root.getChildren().add(leftLeg);
			System.out.println("Placed Body");
			nextBodyPart++;
			break;
		case 5:
			//Right Leg
			Line rightLeg = new Line(200, 250, 200+45, 250+40);
			rightLeg.setFill(Color.WHITE);
			rightLeg.setStroke(Color.BLACK);
			bodyObjects.add(rightLeg);

			root.getChildren().add(rightLeg);
			System.out.println("Placed Body");
			nextBodyPart++;
			//Game Over
			isGameOver = true;
			Text text = new Text(screenWidth/2 - 50, screenHeight/2, "Game Over \nPlease Press Enter");
			text.setScaleX(2);
			text.setScaleY(2);
			text.setTextAlignment(TextAlignment.CENTER);
			textObjects.add(text);
			root.getChildren().add(text);
			System.out.println("Placed Game Over " + "\nPlease Press Enter");
			break;
		}
	}
	public String asterisks() {
		String out = "";
		for(int i = 0; i < selectedWord.length(); i++) {
			out += hiddenSymbol;
		}
		return out;
	}
	public boolean isCorrectLetter(Character c) {
		for(int i = 0; i < lettersInHiddenWord.size(); i++) {
			if(lettersInHiddenWord.get(i).equals(c) && lettersFound.get(i).equals(false)) {
				System.out.println("Letter " + c +" Correct!");
				//Set index of correct letter
				indexOfCorrectLetter = i;
				lettersFound.remove(i);
				lettersFound.add(i, true);
				return true;
			}
		}
		System.out.println("Letter " + c +" Incorrect!");
		return false;
	}
	public String UpdateHiddenWord(Character c) {
		StringBuilder sb = new StringBuilder();
		//Create list of chars of hiddenWord
		ArrayList<Character> tempChars = new ArrayList<Character>();
		for(int i = 0; i < selectedWord.length(); i++) {
			tempChars.add(hiddenWord.getText().charAt(i));
		}
		tempChars.remove(indexOfCorrectLetter);
		tempChars.add(indexOfCorrectLetter, c);
		
		for(Character ch : tempChars) {
			sb.append(ch);
		}
		return sb.toString();
		
	}
	public boolean isComplete() {
		for(Boolean b : lettersFound) {
			if(b == false) {
				return false;
			}
		}
		return true;
	}
	public void ClearGame(BorderPane root) {
		root.getChildren().removeAll(textObjects);
		root.getChildren().removeAll(bodyObjects);
		
		selectedWord = SelectWord();
		System.out.println("Selected Word: " + selectedWord);
		
		lettersInHiddenWord.clear();
		lettersFound.clear();
		hiddenWord.setText("");
		nextBodyPart = 0;
	}
	public void SetupGame(BorderPane root) {
		//Select Random Word
		selectedWord = SelectWord();
		System.out.println("Selected Word: " + selectedWord);

		//Set letter list
		for(int i = 0; i < selectedWord.length(); i++) {
			lettersInHiddenWord.add(selectedWord.charAt(i));
			lettersFound.add(false);
		}
		
		//Create a text that is asterisks the length of the selected word.
		
		hiddenWord.setText(asterisks());
		hiddenWord.setScaleX(2);
		hiddenWord.setScaleY(2);
		
	}
	public static double getScreenWidth(){
		return screenWidth;
	}
	public static double getScreenHeight(){
		return screenWidth;
	}
	
	public static void main(String[] args) {
		launch(args);
	}
}
